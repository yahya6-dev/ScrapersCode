from urllib.request import urlopen
import zipfile
from io import BytesIO

def process_file(name,db,cur,url,root):
	file = open(name,"r")
	for line in file:
		texts = line.split("|")[:-1]
		texts = [text  for text in texts if text not in ["MA","ME"] ]
		reg = texts[1]
		name = texts[2]
		state = texts[3]
		country = text[4]
		fields = [name,'',couuntry,state,'[]','','','','','',reg,'','','','','','','',root,url]
		dump_to_sql(fields)
		


def main_irs():
	root = "https://www.irs.gov/charities-non-profits/tax-exempt-organization-search-bulk-data-downloads"
	urls = ["https://apps.irs.gov/pub/epostcard/data-download-revocation.zip",
	             "https://apps.irs.gov/pub/epostcard/data-download-pub78.zip"]
	for url in urls:
		try:
			response = urlopen(url)
			z_file = zipfile.ZipFile(BytesIO(response.read()))
			os.mkdir("temp")
			conn,cursor = open_db()
		except:
			print("failed to fetch")
			pass
		else:
			z_file.extract_all("temp")
			for base,sub,files in  in os.walk("temp"):
				for fname in files:
					process_file(os.path.join(base,fname),conn,cursor,url,root)


